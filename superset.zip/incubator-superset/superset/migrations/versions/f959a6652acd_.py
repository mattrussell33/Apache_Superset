# -*- coding: utf-8 -*-
"""empty message

Revision ID: f959a6652acd
Revises: ('472d2f73dfd4', 'd39b1e37131d')
Create Date: 2017-09-24 20:18:35.791707

"""

# revision identifiers, used by Alembic.
revision = 'f959a6652acd'
down_revision = ('472d2f73dfd4', 'd39b1e37131d')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
