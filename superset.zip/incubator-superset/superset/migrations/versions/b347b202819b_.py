# -*- coding: utf-8 -*-
"""empty message

Revision ID: b347b202819b
Revises: ('33d996bcc382', '65903709c321')
Create Date: 2016-09-19 17:22:40.138601

"""

# revision identifiers, used by Alembic.
revision = 'b347b202819b'
down_revision = ('33d996bcc382', '65903709c321')


def upgrade():
    pass


def downgrade():
    pass
