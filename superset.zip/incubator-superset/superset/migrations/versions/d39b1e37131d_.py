# -*- coding: utf-8 -*-
"""empty message

Revision ID: d39b1e37131d
Revises: ('a9c47e2c1547', 'ddd6ebdd853b')
Create Date: 2017-09-19 15:09:14.292633

"""

# revision identifiers, used by Alembic.
revision = 'd39b1e37131d'
down_revision = ('a9c47e2c1547', 'ddd6ebdd853b')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
