# -*- coding: utf-8 -*-
"""empty message

Revision ID: 472d2f73dfd4
Revises: ('19a814813610', 'a9c47e2c1547')
Create Date: 2017-09-21 18:37:30.844196

"""

# revision identifiers, used by Alembic.
revision = '472d2f73dfd4'
down_revision = ('19a814813610', 'a9c47e2c1547')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
