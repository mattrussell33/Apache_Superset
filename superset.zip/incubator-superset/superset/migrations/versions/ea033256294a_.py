# -*- coding: utf-8 -*-
"""empty message

Revision ID: ea033256294a
Revises: ('732f1c06bcbf', 'b318dfe5fb6c')
Create Date: 2017-03-16 14:55:59.431283

"""

# revision identifiers, used by Alembic.
revision = 'ea033256294a'
down_revision = ('732f1c06bcbf', 'b318dfe5fb6c')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
