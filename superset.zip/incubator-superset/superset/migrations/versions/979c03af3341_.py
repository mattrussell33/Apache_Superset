# -*- coding: utf-8 -*-
"""empty message

Revision ID: 979c03af3341
Revises: ('db527d8c4c78', 'ea033256294a')
Create Date: 2017-03-21 15:41:34.383808

"""

# revision identifiers, used by Alembic.
revision = '979c03af3341'
down_revision = ('db527d8c4c78', 'ea033256294a')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
